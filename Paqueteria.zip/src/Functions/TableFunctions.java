package Functions;

import java.sql.ResultSet;

public class TableFunctions {

    private DBRequests db = new DBRequests();
    private ResultSet rs;


}
